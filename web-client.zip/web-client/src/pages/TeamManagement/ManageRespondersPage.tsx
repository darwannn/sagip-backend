const ManageRespondersPage = () => {
  return (
    <div className="flex-grow">
      <h1 className="text-2xl font-bold text-gray-500 text-center mt-10">
        Select a team to view the details
      </h1>
    </div>
  );
};

export default ManageRespondersPage;
