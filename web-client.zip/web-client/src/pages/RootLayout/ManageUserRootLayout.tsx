import { Outlet } from "react-router-dom";

const ManageUserRootLayout = () => {
  return <Outlet />;
};

export default ManageUserRootLayout;
