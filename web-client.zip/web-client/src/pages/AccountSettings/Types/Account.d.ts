//import { User } from "../../../types/user";

/* export type TTeam = {
  _id: string;
  name: string;
  head: User;
  members: User[];
  response: number;
  createdAt: string;
  updatedAt: string;
  __v?: number;
};

type TResponder = {
  _id: string;
  firstname: string;
  middlename?: string;
  lastname: string;
  email: string;
  teamName?: string;
  teamId?: string;
};

type TResponders = {
  success: boolean;
  assignedResponders: User[];
  // unassignedResponders: Responder[];
  unassignedResponders: User[];
  responders: User[];
};
 */
export type TAccountResponse = {
  message: string;
  success: boolean;

  firstname?: string;
  middlename?: string;
  lastname?: string;
  contactNumber?: string;
  email?: string;
  region?: string;
  province?: string;
  municipality?: string;
  barangay?: string;
  street?: string;
  gender?: string;
  birthdate?: string;
  password?: string;
  profilePicture?: string;
  attempt?: number;
  verificationCode?: number;
  verificationPicture?: string[];
};
