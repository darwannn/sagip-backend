const EmergencyReportsPage = () => {
  return (
    <>
      <h1>Emergency Reports Page</h1>
    </>
  );
};

export default EmergencyReportsPage;
